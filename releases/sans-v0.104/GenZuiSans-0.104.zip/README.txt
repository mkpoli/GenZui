GenZui Sans / 源萃ゴシック 0.104
Regular and Bold · 17,096 encoded characters

Install the two TTF files, or load genzui-sans.css beside the WOFF2 files.
Open index.html for editable Okinawan samples.

This release preserves Sans 0.103 and adds 27 Funatsu forms and eight raised
katakana. Kana, kanji, hentaigana and historical forms remain available.
The separate GenZui Sans Okinawan subset contains 805 encoded characters
for kana sentences. It does not include kanji.

Private-use characters require a compatible font: see okinawan-mappings.json.
The extension audit is in okinawan-checks.json; baseline-0.103-checks files
record the original release's checks. Source notices accompany these OFL fonts.
