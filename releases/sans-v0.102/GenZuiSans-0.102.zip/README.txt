GenZui Sans / 源萃ゴシック
Regular and Bold · Version 0.102

Install
-------
Open GenZuiSans-Regular.ttf and GenZuiSans-Bold.ttf and choose Install.
Select GenZui Sans or 源萃ゴシック in your application; Bold is the family's
bold style. This family can coexist with GenZui Serif.

Web
---
Keep genzui-sans.css beside the two WOFF2 files, load the stylesheet, then use
font-family: "GenZui Sans", sans-serif. font-weight: 700 selects Bold.

Specimens
---------
Open index.html for editable horizontal and vertical text. The page embeds
the Regular font and works offline. preview.png provides a static overview.

Coverage and features
---------------------
17,070 encoded characters, including all 286 hentaigana and all
763 characters in Unicode 18's Hiragana/Katakana scripts and script extensions.
Noto Sans JP Regular and Bold supply the Japanese base. Noto Sans Hentaigana
supplies 290 historical forms from instances matched to each weight; GenSeki
Hentaigana Gothic Regular and Bold supply 21 further forms.

Minnan tone placement supports one to four fullwidth kana in vertical text
at default spacing. Longer groups need application-level positioning.

Licensing
---------
Fonts and derived outlines: SIL Open Font License 1.1. See OFL.txt and the
individual source licences. NOTICE.txt credits the contributing projects.

checks.json and checks-bold.json record outline, coverage and HarfBuzz
shaping validation for each face.
browser-checks.json identifies the browser engines tested with these files.
