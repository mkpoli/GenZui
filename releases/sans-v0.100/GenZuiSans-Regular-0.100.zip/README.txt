GenZui Sans / 源萃ゴシック
Regular · Version 0.100

Install
-------
Open GenZuiSans-Regular.ttf and choose Install. Select GenZui Sans or
源萃ゴシック in your application. This family can coexist with GenZui Serif.

Web
---
Keep genzui-sans.css beside GenZuiSans-Regular.woff2, load the stylesheet,
then use font-family: "GenZui Sans", sans-serif.

Specimens
---------
Open index.html for editable horizontal and vertical text. The page embeds
the font and works offline. preview.png provides a static overview.

Coverage and features
---------------------
17,070 encoded characters, including all 286 hentaigana and all
763 characters in Unicode 18's Hiragana/Katakana scripts and script extensions.
Noto Sans JP Regular supplies the Japanese base. Noto Sans Hentaigana supplies
290 historical forms; GenSeki Hentaigana Gothic supplies 21 further forms.

Minnan tone placement supports one to four fullwidth kana in vertical text
at default spacing. Longer groups need application-level positioning.

Licensing
---------
Fonts and derived outlines: SIL Open Font License 1.1. See OFL.txt and the
individual source licences. NOTICE.txt credits the contributing projects.

checks.json records outline, coverage and HarfBuzz shaping validation.
browser-checks.json identifies the browser engines tested with these files.
